#!/bin/bash
export PORT=3000
npm install --production
npm start
